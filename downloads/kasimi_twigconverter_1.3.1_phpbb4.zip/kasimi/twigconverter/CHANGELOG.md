# Changelog

## 1.3.1

- Added compatibility with PHP 8.2 and phpBB 4.0.
- Replaced the removed `\Twig_Source` class with `Twig\Source`.
- Updated style detection to support phpBB 4.0 styles using `composer.json` with the `phpbb-style` package type.
- Kept support for legacy styles using `style.cfg`.
- Updated Composer requirements to PHP 8.2 and phpBB 4.0.x.

## 1.3.0

- Original release by kasimi.
